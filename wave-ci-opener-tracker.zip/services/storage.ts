
import { User, GlobalSettings, AgentProgress, DailyReport, StockItem, Language, MerchantType } from '../types';

const USERS_KEY = 'wave_users_v4';
const SETTINGS_KEY = 'wave_settings_v4';
const CURRENT_USER_ID = 'wave_current_user_v4';
const PROGRESS_KEY = 'wave_progress_v4';
const REPORTS_KEY = 'wave_reports_v4';
const LANG_KEY = 'wave_lang_v4';

const DEFAULT_INDIVIDUAL_TARGETS = { 
  'Fixe': 2, 
  'Ambulant': 3, 
  'Taxi': 1, 
  'Moto Taxi': 2,
  'Prospection': 10,
  'Visite': 5 
};

const DEFAULT_TEAM_TARGETS = { 
  'Fixe': 20, 
  'Ambulant': 30, 
  'Taxi': 10, 
  'Moto Taxi': 20,
  'Prospection': 100,
  'Visite': 50 
};

const getStartOfWeek = () => {
  const d = new Date();
  const day = d.getDay(), diff = d.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(d.setDate(diff)).toISOString().split('T')[0];
};

const getStartOfCycle = () => {
  const d = new Date();
  const month = d.getMonth();
  const cycleStartMonth = month - (month % 2);
  return new Date(d.getFullYear(), cycleStartMonth, 1).toISOString().split('T')[0];
};

export const storage = {
  getUsers: (): User[] => {
    const data = localStorage.getItem(USERS_KEY);
    return data ? JSON.parse(data) : [];
  },
  
  saveUser: (user: User) => {
    const users = storage.getUsers();
    const index = users.findIndex(u => u.id === user.id);
    if (index >= 0) users[index] = user;
    else users.push(user);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  },

  findUserByPhone: (phone: string): User | undefined => {
    return storage.getUsers().find(u => u.phone === phone);
  },

  setCurrentUser: (userId: string | null) => {
    if (userId) localStorage.setItem(CURRENT_USER_ID, userId);
    else localStorage.removeItem(CURRENT_USER_ID);
  },

  getCurrentUser: (): User | null => {
    const id = localStorage.getItem(CURRENT_USER_ID);
    if (!id) return null;
    return storage.getUsers().find(u => u.id === id) || null;
  },

  getSettings: (): GlobalSettings => {
    const data = localStorage.getItem(SETTINGS_KEY);
    if (data) return JSON.parse(data);

    return {
      individualTargets: {
        today: { ...DEFAULT_INDIVIDUAL_TARGETS },
        week: { ...DEFAULT_INDIVIDUAL_TARGETS, 'Fixe': 10, 'Ambulant': 15, 'Visite': 25, 'Prospection': 50 },
        month: { ...DEFAULT_INDIVIDUAL_TARGETS, 'Fixe': 40, 'Ambulant': 60, 'Visite': 100, 'Prospection': 200 },
        cycle: { ...DEFAULT_INDIVIDUAL_TARGETS, 'Fixe': 80, 'Ambulant': 120, 'Visite': 200, 'Prospection': 400 }
      },
      teamTargets: {
        today: { ...DEFAULT_TEAM_TARGETS },
        week: { ...DEFAULT_TEAM_TARGETS, 'Fixe': 100, 'Ambulant': 150, 'Visite': 250, 'Prospection': 500 },
        month: { ...DEFAULT_TEAM_TARGETS, 'Fixe': 400, 'Ambulant': 600, 'Visite': 1000, 'Prospection': 2000 },
        cycle: { ...DEFAULT_TEAM_TARGETS, 'Fixe': 800, 'Ambulant': 1200, 'Visite': 2000, 'Prospection': 4000 }
      }
    };
  },

  updateSettings: (settings: GlobalSettings) => {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  },

  getAgentProgress: (userId: string): AgentProgress => {
    const allProgress = localStorage.getItem(PROGRESS_KEY);
    const parsed = allProgress ? JSON.parse(allProgress) : {};
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const weekStr = getStartOfWeek();
    const monthStr = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
    const cycleStr = getStartOfCycle();

    const emptyCounts: Record<MerchantType, number> = { 
      'Fixe': 0, 'Ambulant': 0, 'Taxi': 0, 'Moto Taxi': 0, 'Visite': 0, 'Prospection': 0
    };

    let p: AgentProgress = parsed[userId] || {
      userId,
      lastResets: { today: todayStr, week: weekStr, month: monthStr, cycle: cycleStr },
      counts: { today: { ...emptyCounts }, week: { ...emptyCounts }, month: { ...emptyCounts }, cycle: { ...emptyCounts } }
    };

    // Check Resets
    if (p.lastResets.today !== todayStr) { p.counts.today = { ...emptyCounts }; p.lastResets.today = todayStr; }
    if (p.lastResets.week !== weekStr) { p.counts.week = { ...emptyCounts }; p.lastResets.week = weekStr; }
    if (p.lastResets.month !== monthStr) { p.counts.month = { ...emptyCounts }; p.lastResets.month = monthStr; }
    if (p.lastResets.cycle !== cycleStr) { p.counts.cycle = { ...emptyCounts }; p.lastResets.cycle = cycleStr; }

    storage.updateAgentProgress(p);
    return p;
  },

  updateAgentProgress: (progress: AgentProgress) => {
    const allProgress = localStorage.getItem(PROGRESS_KEY);
    const parsed = allProgress ? JSON.parse(allProgress) : {};
    parsed[progress.userId] = progress;
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(parsed));
  },

  getAgentStock: (userId: string): StockItem[] => {
    const saved = localStorage.getItem(`stock_${userId}`);
    return saved ? JSON.parse(saved) : [];
  },

  saveDailyReport: (report: DailyReport) => {
    const data = localStorage.getItem(REPORTS_KEY);
    const reports: DailyReport[] = data ? JSON.parse(data) : [];
    reports.push(report);
    localStorage.setItem(REPORTS_KEY, JSON.stringify(reports));
  },

  updateDailyReport: (reportId: string, updatedData: Partial<DailyReport>) => {
    const data = localStorage.getItem(REPORTS_KEY);
    if (!data) return;
    const reports: DailyReport[] = JSON.parse(data);
    const index = reports.findIndex(r => r.id === reportId);
    if (index >= 0) {
      reports[index] = { ...reports[index], ...updatedData };
      localStorage.setItem(REPORTS_KEY, JSON.stringify(reports));
    }
  },

  getDailyReports: (): DailyReport[] => {
    const data = localStorage.getItem(REPORTS_KEY);
    return data ? JSON.parse(data) : [];
  },

  getLanguage: (): Language => {
    return (localStorage.getItem(LANG_KEY) as Language) || 'fr';
  },

  setLanguage: (lang: Language) => {
    localStorage.setItem(LANG_KEY, lang);
  }
};

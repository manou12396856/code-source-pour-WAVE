
import React from 'react';

interface TargetBarProps {
  category: string;
  current: number;
  target: number;
}

const TargetBar: React.FC<TargetBarProps> = ({ category, current, target }) => {
  const percentage = Math.min(Math.round((current / target) * 100), 100);
  const isComplete = current >= target;
  
  return (
    <div className="mb-5">
      <div className="flex justify-between items-end mb-2">
        <span className="text-xs font-black text-gray-700 uppercase tracking-tight">{category}</span>
        <span className="text-xs font-medium text-gray-400">
          <span className={`font-black ${isComplete ? 'text-green-500' : 'text-[#009FE3]'}`}>{current}</span>
          <span className="mx-1 text-[10px]">/</span>
          {target}
        </span>
      </div>
      <div className="w-full h-3.5 bg-gray-100 rounded-full overflow-hidden p-0.5 border border-gray-50 shadow-inner">
        <div 
          className={`h-full transition-all duration-1000 rounded-full shadow-sm flex items-center justify-end px-1 ${isComplete ? 'bg-gradient-to-r from-green-400 to-green-500' : 'bg-gradient-to-r from-[#009FE3] to-[#007BB0]'}`}
          style={{ width: `${percentage}%` }}
        >
          {percentage > 15 && <div className="w-1.5 h-1.5 bg-white/40 rounded-full animate-pulse"></div>}
        </div>
      </div>
    </div>
  );
};

export default TargetBar;

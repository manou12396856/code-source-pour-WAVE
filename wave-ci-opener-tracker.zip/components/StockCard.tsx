
import React from 'react';
import { MATERIAL_ICONS } from '../constants';

interface StockCardProps {
  name: string;
  quantity: number;
}

const StockCard: React.FC<StockCardProps> = ({ name, quantity }) => {
  const isLow = quantity < 5;

  return (
    <div className="bg-white p-3 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center">
      <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${isLow ? 'bg-red-50 text-red-500' : 'bg-blue-50 text-[#009FE3]'}`}>
        {MATERIAL_ICONS[name] || <span className="text-xs">?</span>}
      </div>
      <span className="text-[10px] font-medium text-gray-400 uppercase tracking-wider mb-1">{name}</span>
      <span className={`text-xl font-bold ${isLow ? 'text-red-600' : 'text-gray-800'}`}>{quantity}</span>
    </div>
  );
};

export default StockCard;

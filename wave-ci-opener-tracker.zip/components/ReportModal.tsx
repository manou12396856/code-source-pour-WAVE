
import React from 'react';
import { X, Copy, MessageCircle } from 'lucide-react';
import { PerformanceTarget, StockItem } from '../types';

interface ReportModalProps {
  performance: PerformanceTarget[];
  stock: StockItem[];
  userName: string;
  onClose: () => void;
}

const ReportModal: React.FC<ReportModalProps> = ({ performance, stock, userName, onClose }) => {
  const dateStr = new Date().toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  
  const reportText = `🚀 *RAPPORT JOURNALIER - WAVE CI* 🚀
👤 Agent: ${userName}
📅 Date: ${dateStr}

📊 *PERFORMANCES:*
${performance.map(p => `• ${p.category}: ${p.current} / ${p.target}`).join('\n')}

📦 *STOCK RESTANT:*
${stock.map(s => `• ${s.name}: ${s.quantity}`).join('\n')}

✅ Total Créations du jour: ${performance.reduce((acc, curr) => acc + curr.current, 0)}

#WaveCI #MerchantOpener`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(reportText);
    alert('Rapport copié dans le presse-papier !');
  };

  const shareToWhatsApp = () => {
    const url = `https://wa.me/?text=${encodeURIComponent(reportText)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-[32px] overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200">
        <div className="bg-[#009FE3] p-6 text-white flex justify-between items-center">
          <h2 className="text-xl font-bold">Générer Rapport</h2>
          <button onClick={onClose} className="p-1 bg-white/20 rounded-full">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-6">
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 mb-6 font-mono text-xs whitespace-pre-wrap leading-relaxed max-h-60 overflow-y-auto">
            {reportText}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={copyToClipboard}
              className="flex items-center justify-center gap-2 py-3 border-2 border-slate-100 rounded-2xl font-bold text-gray-600 active:bg-slate-50"
            >
              <Copy size={18} />
              Copier
            </button>
            <button 
              onClick={shareToWhatsApp}
              className="flex items-center justify-center gap-2 py-3 bg-[#25D366] text-white rounded-2xl font-bold shadow-lg shadow-green-500/20 active:scale-95 transition-transform"
            >
              <MessageCircle size={18} />
              WhatsApp
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportModal;


import React, { useState } from 'react';
import { X, Check } from 'lucide-react';
import { StockItem, MerchantType } from '../types';

interface MaterialSelectorModalProps {
  type: MerchantType | null;
  stock: StockItem[];
  onClose: () => void;
  onSubmit: (usedMaterials: Record<string, number>) => void;
}

const MaterialSelectorModal: React.FC<MaterialSelectorModalProps> = ({ type, stock, onClose, onSubmit }) => {
  const [selections, setSelections] = useState<Record<string, number>>({});

  if (!type) return null;

  const toggleSelection = (id: string) => {
    setSelections(prev => ({
      ...prev,
      [id]: prev[id] ? 0 : 1
    }));
  };

  const updateQuantity = (id: string, delta: number) => {
    setSelections(prev => ({
      ...prev,
      [id]: Math.max(0, (prev[id] || 0) + delta)
    }));
  };

  const handleConfirm = () => {
    onSubmit(selections);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end justify-center sm:items-center p-4">
      <div className="bg-white w-full max-w-md rounded-t-[32px] sm:rounded-3xl p-6 shadow-2xl animate-in slide-in-from-bottom duration-300">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-xl font-bold text-gray-800">Ajouter Marchand {type}</h2>
            <p className="text-sm text-gray-500">Quel matériel avez-vous utilisé ?</p>
          </div>
          <button onClick={onClose} className="p-2 bg-gray-100 rounded-full">
            <X size={20} />
          </button>
        </div>

        <div className="space-y-4 mb-8">
          {stock.map((item) => (
            <div key={item.id} className="flex items-center justify-between p-3 rounded-2xl border border-gray-100 hover:border-[#009FE3]/30 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center text-[#009FE3]">
                   <span className="text-xs font-bold">{item.name.charAt(0)}</span>
                </div>
                <span className="font-medium text-gray-700">{item.name}</span>
              </div>
              
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => updateQuantity(item.id, -1)}
                  className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center text-gray-500 disabled:opacity-30"
                  disabled={!selections[item.id]}
                >
                  -
                </button>
                <span className="w-6 text-center font-bold text-gray-800">{selections[item.id] || 0}</span>
                <button 
                  onClick={() => updateQuantity(item.id, 1)}
                  className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center text-gray-500"
                >
                  +
                </button>
              </div>
            </div>
          ))}
        </div>

        <button 
          onClick={handleConfirm}
          className="w-full py-4 bg-[#009FE3] text-white rounded-2xl font-bold shadow-lg shadow-[#009FE3]/20 flex items-center justify-center gap-2 active:scale-95 transition-transform"
        >
          <Check size={20} />
          Confirmer la création
        </button>
      </div>
    </div>
  );
};

export default MaterialSelectorModal;

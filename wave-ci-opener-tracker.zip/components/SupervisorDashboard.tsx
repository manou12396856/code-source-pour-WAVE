
import React, { useState, useEffect } from 'react';
import { storage } from '../services/storage';
import { MapPin, Users, Package, ChevronDown, ChevronUp, AlertTriangle, CheckCircle2, RefreshCw, MapPinned, Search, TrendingUp, History, Sparkles } from 'lucide-react';
import { User, MerchantType, PeriodType } from '../types';
import { INITIAL_STOCK } from '../mockData';

interface SupervisorDashboardProps {
  t: (path: string) => string;
  language?: string;
}

const SupervisorDashboard: React.FC<SupervisorDashboardProps> = ({ t, language }) => {
  const [agents, setAgents] = useState<User[]>([]);
  const [expandedAgent, setExpandedAgent] = useState<string | null>(null);
  const [selectedPeriod, setSelectedPeriod] = useState<PeriodType>('today');
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [teamStats, setTeamStats] = useState<Record<string, number>>({});
  
  const settings = storage.getSettings();

  useEffect(() => {
    const refreshData = () => {
      const allUsers = storage.getUsers();
      const agentList = allUsers.filter(u => u.role === 'agent');
      setAgents(agentList);
      
      const totals: Record<string, number> = {};
      agentList.forEach(agent => {
        const p = storage.getAgentProgress(agent.id);
        const periodCounts = p.counts[selectedPeriod];
        Object.entries(periodCounts).forEach(([cat, val]) => {
          totals[cat] = (totals[cat] || 0) + (val as number);
        });
      });
      setTeamStats(totals);
      setLastUpdate(new Date());
    };
    refreshData();
    const interval = setInterval(refreshData, 5000);
    return () => clearInterval(interval);
  }, [selectedPeriod]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-10">
      <div className="flex items-center justify-between px-2 mb-2">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
          <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Live: {lastUpdate.toLocaleTimeString()}</span>
        </div>
        <button onClick={() => window.location.reload()} className="p-1 text-[#009FE3]"><RefreshCw size={14} /></button>
      </div>

      <div className="bg-white rounded-[32px] p-6 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-50 text-[#009FE3] rounded-xl flex items-center justify-center"><TrendingUp size={18} /></div>
            <h3 className="text-xs font-black text-gray-800 uppercase tracking-widest">Team Performance</h3>
          </div>
          <div className="flex bg-gray-50 p-1 rounded-xl">
            {(['today', 'week', 'month', 'cycle'] as PeriodType[]).map(p => (
              <button 
                key={p} 
                onClick={() => setSelectedPeriod(p)}
                className={`px-3 py-1.5 rounded-lg text-[8px] font-black uppercase transition-all ${selectedPeriod === p ? 'bg-white text-[#009FE3] shadow-sm' : 'text-gray-400'}`}
              >
                {t(`periods.${p}`)}
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-5">
          {['Prospection', 'Fixe', 'Ambulant', 'Taxi', 'Moto Taxi'].map(cat => {
            const current = teamStats[cat] || 0;
            const target = settings.teamTargets[selectedPeriod][cat as MerchantType] || 10;
            const percentage = Math.min(100, (current / target) * 100);
            const isDone = current >= target;
            return (
              <div key={cat}>
                <div className="flex justify-between items-end mb-1">
                  <span className="text-[10px] font-black text-gray-700 uppercase flex items-center gap-1">
                    {cat} {isDone && <Sparkles size={10} className="text-yellow-500 animate-bounce" />}
                  </span>
                  <span className="text-[10px] font-black text-gray-400">
                    <span className="text-[#009FE3] text-xs font-black">{current}</span> / {target}
                  </span>
                </div>
                <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden border border-gray-50">
                   <div 
                      className={`h-full transition-all duration-1000 ${isDone ? 'bg-gradient-to-r from-yellow-400 to-yellow-600' : 'bg-[#009FE3]'}`}
                      style={{ width: `${percentage}%` }}
                   />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm flex flex-col items-center">
          <Users size={18} className="text-blue-500 mb-1" />
          <span className="text-[8px] text-gray-400 font-black uppercase">Team</span>
          <span className="text-md font-black">{agents.length}</span>
        </div>
        <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm flex flex-col items-center">
          <MapPinned size={18} className="text-yellow-600 mb-1" />
          <span className="text-[8px] text-gray-400 font-black uppercase">Visits</span>
          <span className="text-md font-black">
            {teamStats['Visite'] || 0}
          </span>
        </div>
        <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm flex flex-col items-center">
          <Search size={18} className="text-emerald-500 mb-1" />
          <span className="text-[8px] text-gray-400 font-black uppercase">Prosp.</span>
          <span className="text-md font-black">
            {teamStats['Prospection'] || 0}
          </span>
        </div>
      </div>

      <div className="bg-white rounded-[32px] shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-5 border-b border-gray-50 bg-slate-50/30">
          <h3 className="font-bold text-gray-800 text-sm tracking-tight">Agent Tracking</h3>
        </div>

        <div className="divide-y divide-gray-50">
          {agents.map((agent) => {
            const stock = storage.getAgentStock(agent.id);
            const progress = storage.getAgentProgress(agent.id);
            const reports = storage.getDailyReports().filter(r => r.userId === agent.id).slice(-3).reverse();
            const isExpanded = expandedAgent === agent.id;
            
            const totalCreasMonth = (Object.entries(progress.counts.month) as [MerchantType, number][])
              .filter(([t]) => t !== 'Visite' && t !== 'Prospection')
              .reduce((a, [, b]) => a + b, 0);

            return (
              <div key={agent.id}>
                <div 
                  onClick={() => setExpandedAgent(isExpanded ? null : agent.id)}
                  className={`p-4 flex items-center justify-between active:bg-gray-50 transition-colors cursor-pointer ${isExpanded ? 'bg-blue-50/50' : ''}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="relative shrink-0">
                      {agent.photo ? (
                        <img src={agent.photo} className="w-10 h-10 rounded-2xl object-cover shadow-sm" />
                      ) : (
                        <div className="w-10 h-10 bg-blue-50 text-blue-500 rounded-2xl flex items-center justify-center font-black">
                          {agent.firstName.charAt(0)}
                        </div>
                      )}
                      <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-black text-gray-800 leading-tight truncate">{agent.firstName}</p>
                      <p className="text-[8px] text-[#009FE3] font-black uppercase tracking-tighter truncate">{agent.zone}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="text-center">
                      <p className="text-[7px] font-black text-gray-400 uppercase leading-none mb-1">Pros.</p>
                      <p className="text-[11px] font-black text-emerald-600">{progress.counts.month['Prospection'] || 0}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[7px] font-black text-gray-400 uppercase leading-none mb-1">Visites</p>
                      <p className="text-[11px] font-black text-[#009FE3]">{progress.counts.month['Visite'] || 0}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[7px] font-black text-gray-400 uppercase leading-none mb-1">Acq.</p>
                      <p className="text-[11px] font-black text-blue-900">{totalCreasMonth}</p>
                    </div>
                    {isExpanded ? <ChevronUp size={14} className="text-[#009FE3]" /> : <ChevronDown size={14} className="text-gray-300" />}
                  </div>
                </div>

                {isExpanded && (
                  <div className="px-5 pb-5 pt-2 bg-slate-50/50 animate-in slide-in-from-top duration-300">
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="bg-white p-3 rounded-2xl border border-gray-100">
                        <p className="text-[8px] font-black text-gray-400 uppercase mb-2">Today: Pros / Visites</p>
                        <div className="flex justify-between items-end">
                          <span className="text-md font-black text-emerald-600">{progress.counts.today['Prospection'] || 0}</span>
                          <span className="text-gray-200 mx-1 text-xs">/</span>
                          <span className="text-md font-black text-[#009FE3]">{progress.counts.today['Visite'] || 0}</span>
                        </div>
                      </div>
                      
                      <div className="bg-white p-3 rounded-2xl border border-gray-100">
                        <p className="text-[8px] font-black text-gray-400 uppercase mb-2">Inventory Tracking</p>
                        <div className="space-y-1.5 max-h-24 overflow-y-auto">
                          {stock.length > 0 ? stock.map(s => {
                            const low = s.quantity < 5;
                            return (
                              <div key={s.id} className="flex justify-between items-center text-[9px] font-bold">
                                <span className={`truncate mr-1 ${low ? 'text-red-500' : 'text-slate-600'}`}>{s.name}</span>
                                <span className={`font-black ${low ? 'bg-red-50 text-red-500' : 'bg-slate-50 text-slate-800'} px-1 rounded`}>{s.quantity}</span>
                              </div>
                            );
                          }) : <p className="text-[9px] italic text-slate-400">Empty</p>}
                        </div>
                      </div>
                    </div>

                    <div className="bg-white p-4 rounded-2xl border border-gray-100">
                       <div className="flex items-center gap-1 mb-3">
                          <History size={12} className="text-gray-400" />
                          <span className="text-[9px] font-black text-gray-400 uppercase">Recent Reports</span>
                       </div>
                       <div className="space-y-2">
                          {reports.map(r => (
                            <div key={r.id} className="flex justify-between items-center text-[10px] pb-2 border-b border-gray-50 last:border-0 last:pb-0">
                               <span className="font-bold text-gray-500">{new Date(r.date).toLocaleDateString(language === 'fr' ? 'fr-FR' : 'en-US', { day: '2-digit', month: 'short' })}</span>
                               <div className="flex gap-2">
                                  <span className="bg-emerald-50 text-emerald-600 px-1.5 rounded font-black">P: {r.prospections}</span>
                                  <span className="bg-blue-50 text-blue-900 px-1.5 rounded font-black">A: {r.creations}</span>
                               </div>
                            </div>
                          ))}
                          {reports.length === 0 && <p className="text-[10px] italic text-gray-400">No history</p>}
                       </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default SupervisorDashboard;

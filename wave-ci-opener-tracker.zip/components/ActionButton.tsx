
import React from 'react';
import { Plus, Store, UserRound, Car, Bike, MapPinned, Search } from 'lucide-react';
import { MerchantType } from '../types';

interface ActionButtonProps {
  type: MerchantType;
  onClick: (type: MerchantType) => void;
}

const getIcon = (type: MerchantType) => {
  switch (type) {
    case 'Fixe': return <Store size={22} />;
    case 'Ambulant': return <UserRound size={22} />;
    case 'Taxi': return <Car size={22} />;
    case 'Moto Taxi': return <Bike size={22} />;
    case 'Visite': return <MapPinned size={22} />;
    case 'Prospection': return <Search size={22} />;
  }
};

const ActionButton: React.FC<ActionButtonProps> = ({ type, onClick }) => {
  const isDirect = type === 'Visite' || type === 'Prospection';
  
  return (
    <button
      onClick={() => onClick(type)}
      className={`flex flex-col items-center justify-center p-4 rounded-3xl shadow-sm border border-gray-100 active:scale-95 transition-transform group ${isDirect ? 'bg-blue-50/50' : 'bg-white'}`}
    >
      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-2 group-active:bg-[#FFD200] ${isDirect ? 'bg-[#009FE3] text-white' : 'bg-[#FFD200]/10 text-[#009FE3]'}`}>
        {getIcon(type)}
      </div>
      <span className={`text-[10px] font-black uppercase tracking-tighter ${isDirect ? 'text-[#009FE3]' : 'text-gray-700'}`}>{type}</span>
    </button>
  );
};

export default ActionButton;


import React from 'react';
import { LogOut, Bell, User as UserIcon } from 'lucide-react';

interface HeaderProps {
  userName: string;
  role: string;
  onLogout: () => void;
  onBellClick: () => void;
  hasUnread?: boolean;
}

const Header: React.FC<HeaderProps> = ({ userName, role, onLogout, onBellClick, hasUnread }) => {
  return (
    <header className="bg-white border-b border-gray-100 px-4 py-3 sticky top-0 z-30 flex items-center justify-between shadow-sm">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-[#009FE3] rounded-xl flex items-center justify-center text-white font-bold text-lg shadow-inner overflow-hidden">
           {userName.charAt(0)}
        </div>
        <div>
          <h1 className="font-bold text-gray-800 text-sm leading-tight">{userName}</h1>
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{role}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button 
          onClick={onBellClick}
          className={`relative p-2 rounded-xl transition-colors ${hasUnread ? 'bg-yellow-50 text-yellow-600' : 'bg-gray-50 text-gray-400'}`}
        >
          <Bell size={20} />
          {hasUnread && (
            <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 border border-white rounded-full"></span>
          )}
        </button>
        <button onClick={onLogout} className="p-2 bg-gray-50 text-gray-400 rounded-xl hover:text-red-500 transition-colors">
          <LogOut size={20} />
        </button>
      </div>
    </header>
  );
};

export default Header;
